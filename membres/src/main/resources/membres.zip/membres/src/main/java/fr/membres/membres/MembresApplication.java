package fr.membres.membres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MembresApplication {

	public static void main(String[] args) {
		SpringApplication.run(MembresApplication.class, args);
	}

}
